// Simple editor + persistence + export/import + print
(function(){
  const editBtn = document.getElementById('editBtn');
  const saveBtn = document.getElementById('saveBtn');
  const downloadPdfBtn = document.getElementById('downloadPdfBtn');
  const exportJsonBtn = document.getElementById('exportJsonBtn');
  const importJsonBtn = document.getElementById('importJsonBtn');
  const importJsonInput = document.getElementById('importJsonInput');

  let editing = false;
  const editableSelectors = [
    '#name','#headline','#phone','#email','#location',
    '#profile','#skills','#languages','#education p',
    '#experience p','#certificates'
  ];

  function setEditable(flag){
    editing = flag;
    editableSelectors.forEach(sel=>{
      const el = document.querySelector(sel);
      if(!el) return;
      el.contentEditable = flag ? "true" : "false";
      if(flag){
        el.classList.add('editing');
      } else {
        el.classList.remove('editing');
      }
    });
    editBtn.style.display = flag ? 'none' : '';
    saveBtn.style.display = flag ? '' : 'none';
  }

  editBtn.addEventListener('click', ()=> setEditable(true));
  saveBtn.addEventListener('click', ()=> {
    setEditable(false);
    saveToLocal();
    alert('Perubahan disimpan (localStorage).');
  });

  downloadPdfBtn.addEventListener('click', ()=>{
    // simple: open print dialog (user can choose save as PDF)
    window.print();
  });

  // Export current content as JSON
  exportJsonBtn.addEventListener('click', ()=>{
    const data = collectData();
    const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'cv-data.json'; document.body.appendChild(a); a.click();
    a.remove(); URL.revokeObjectURL(url);
  });

  importJsonBtn.addEventListener('click', ()=> importJsonInput.click());
  importJsonInput.addEventListener('change', async (e)=>{
    const f = e.target.files[0];
    if(!f) return;
    try{
      const text = await f.text();
      const data = JSON.parse(text);
      applyData(data);
      saveToLocal();
      alert('Data diimpor dan disimpan (localStorage).');
    }catch(err){
      alert('Gagal mengimpor: ' + err.message);
    } finally {
      importJsonInput.value = '';
    }
  });

  // collect page data from editable fields
  function collectData(){
    return {
      name: document.getElementById('name').innerText.trim(),
      headline: document.getElementById('headline').innerText.trim(),
      phone: document.getElementById('phone').innerText.trim(),
      email: document.getElementById('email').innerText.trim(),
      location: document.getElementById('location').innerText.trim(),
      profile: document.getElementById('profile').innerText.trim(),
      skills: [...document.querySelectorAll('#skills li')].map(li=>li.innerText.trim()),
      languages: [...document.querySelectorAll('#languages li')].map(li=>li.innerText.trim()),
      education: {
        institution: document.querySelector('#education strong')?.innerText || '',
        dates: document.querySelector('#education .muted')?.innerText || '',
        notes: document.querySelector('#education p')?.innerText || ''
      },
      experience: {
        title: document.querySelector('#experience strong')?.innerText || '',
        dates: document.querySelector('#experience .muted')?.innerText || '',
        notes: document.querySelector('#experience p')?.innerText || ''
      },
      certificates: [...document.querySelectorAll('#certificates li')].map(li=>li.innerText.trim())
    };
  }

  // apply data object to DOM
  function applyData(data = {}){
    if(data.name) document.getElementById('name').innerText = data.name;
    if(data.headline) document.getElementById('headline').innerText = data.headline;
    if(data.phone) document.getElementById('phone').innerText = data.phone;
    if(data.email) document.getElementById('email').innerText = data.email;
    if(data.location) document.getElementById('location').innerText = data.location;
    if(data.profile) document.getElementById('profile').innerText = data.profile;
    if(Array.isArray(data.skills)){
      const skills = document.getElementById('skills');
      skills.innerHTML = data.skills.map(s=>`<li>${s}</li>`).join('');
    }
    if(Array.isArray(data.languages)){
      const lang = document.getElementById('languages');
      lang.innerHTML = data.languages.map(s=>`<li>${s}</li>`).join('');
    }
    if(data.education){
      if(data.education.institution) document.querySelector('#education strong').innerText = data.education.institution;
      if(data.education.dates) document.querySelector('#education .muted').innerText = data.education.dates;
      if(data.education.notes) document.querySelector('#education p').innerText = data.education.notes;
    }
    if(data.experience){
      if(data.experience.title) document.querySelector('#experience strong').innerText = data.experience.title;
      if(data.experience.dates) document.querySelector('#experience .muted').innerText = data.experience.dates;
      if(data.experience.notes) document.querySelector('#experience p').innerText = data.experience.notes;
    }
    if(Array.isArray(data.certificates)){
      const cert = document.getElementById('certificates');
      cert.innerHTML = data.certificates.map(s=>`<li>${s}</li>`).join('');
    }
  }

  // localStorage persistence
  const LOCAL_KEY = 'cv_template_data_v1';
  function saveToLocal(){ localStorage.setItem(LOCAL_KEY, JSON.stringify(collectData())) }
  function loadFromLocal(){
    const raw = localStorage.getItem(LOCAL_KEY);
    if(!raw) return null;
    try { return JSON.parse(raw) } catch(e){ return null }
  }

  // on load: try local storage, else sample
  document.addEventListener('DOMContentLoaded', ()=>{
    const data = loadFromLocal();
    if(data) applyData(data);
  });

})();